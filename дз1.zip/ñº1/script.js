//let tempCelsius = prompt('Какая температура в Цельсиях?');
//let tempFahrenheit = (9/5) * tempCelsius + 32;
//console.log(tempFahrenheit);

let name = prompt('Введите имя');
let admin = name;
console.log(admin);